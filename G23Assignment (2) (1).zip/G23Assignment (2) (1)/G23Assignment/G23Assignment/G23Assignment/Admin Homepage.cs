﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace G23Assignment
{
    public partial class Admin_Homepage : Form
    {
        public Admin_Homepage(string N)
        {
            InitializeComponent();
            Name = N;
        }

        // Event handler for clicking the "Profile" button
        private void btnProfile_Click(object sender, EventArgs e)
        {
            this.Close();
            // Open the admin profile page
            Admin_Profile_page ap = new Admin_Profile_page(Name);
            ap.Show();
        }

        // Event handler for clicking the "Register" button
        private void btnRegister_Click(object sender, EventArgs e)
        {
            this.Close();
            // Open the registration page
            Registration_page rp = new Registration_page(Name);
            rp.Show();
        }

        // Event handler for clicking the "Income Report" button
        private void btnIncomeReport_Click(object sender, EventArgs e)
        {
            this.Close();
            // Open the income report page
            Income_Report_page ir = new Income_Report_page(Name);
            ir.Show();
        }

        // Event handler for clicking the "Trainer Feedback" button
        private void btnTrainerFeedback_Click(object sender, EventArgs e)
        {
            this.Close();
            // Open the trainer feedback page
            Trainer_Feedback_page tf = new Trainer_Feedback_page(Name);
            tf.Show();
        }

        // Event handler for clicking the "Delete Trainer" button
        private void btnDeleteTrainer_Click(object sender, EventArgs e)
        {
            this.Close();

           // string adminName = "luai"; 
            Delete_Trainer_page dt = new Delete_Trainer_page(Name); // Open the delete trainer page
            dt.Show();
        }

        // Event handler for clicking the "Logout" button
        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close();

            frmLogin fr = new frmLogin();// Open the login form
            fr.Show();
        }

        private void Admin_Homepage_Load(object sender, EventArgs e)
        {
            lblWelcome.Text = "Hello, " + Name;
        }
    }
}

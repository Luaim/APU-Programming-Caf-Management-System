﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace G23Assignment
{
    public partial class Requests : Form
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());
        public Requests()
        {
            InitializeComponent();
        }

        private void Requests_Load(object sender, EventArgs e)
        {
            ArrayList name = new ArrayList();

            name = students.studentRequests();
            foreach (var item in name)
            {
                lstName.Items.Add(item);
                
              
            }

        }

        private void btnApprove_Click(object sender, EventArgs e)
        {
            students obj1 = new students(lstName.SelectedItems.ToString());
            MessageBox.Show(obj1.RequestStatus(lstName));

            lstName.Items.Remove(lstName.SelectedItem);


        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void lstName_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
    }
}

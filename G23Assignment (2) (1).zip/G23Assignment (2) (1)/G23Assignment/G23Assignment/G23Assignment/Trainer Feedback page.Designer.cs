﻿namespace G23Assignment
{
    partial class Trainer_Feedback_page
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTrainerFeedback = new System.Windows.Forms.Label();
            this.lblTrainerName = new System.Windows.Forms.Label();
            this.cboTrainerName = new System.Windows.Forms.ComboBox();
            this.txtFeedback = new System.Windows.Forms.TextBox();
            this.btnDisplay = new System.Windows.Forms.Button();
            this.btnReturn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTrainerFeedback
            // 
            this.lblTrainerFeedback.AutoSize = true;
            this.lblTrainerFeedback.Font = new System.Drawing.Font("Times New Roman", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTrainerFeedback.Location = new System.Drawing.Point(325, 37);
            this.lblTrainerFeedback.Name = "lblTrainerFeedback";
            this.lblTrainerFeedback.Size = new System.Drawing.Size(236, 34);
            this.lblTrainerFeedback.TabIndex = 1;
            this.lblTrainerFeedback.Text = "Trainer Feedback";
            // 
            // lblTrainerName
            // 
            this.lblTrainerName.AutoSize = true;
            this.lblTrainerName.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTrainerName.Location = new System.Drawing.Point(118, 120);
            this.lblTrainerName.Name = "lblTrainerName";
            this.lblTrainerName.Size = new System.Drawing.Size(127, 23);
            this.lblTrainerName.TabIndex = 2;
            this.lblTrainerName.Text = "Trainer Name";
            // 
            // cboTrainerName
            // 
            this.cboTrainerName.FormattingEnabled = true;
            this.cboTrainerName.Location = new System.Drawing.Point(243, 117);
            this.cboTrainerName.Name = "cboTrainerName";
            this.cboTrainerName.Size = new System.Drawing.Size(155, 30);
            this.cboTrainerName.TabIndex = 3;
            this.cboTrainerName.SelectedIndexChanged += new System.EventHandler(this.cboTrainerName_SelectedIndexChanged);
            // 
            // txtFeedback
            // 
            this.txtFeedback.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFeedback.Location = new System.Drawing.Point(122, 167);
            this.txtFeedback.Multiline = true;
            this.txtFeedback.Name = "txtFeedback";
            this.txtFeedback.Size = new System.Drawing.Size(537, 125);
            this.txtFeedback.TabIndex = 4;
            // 
            // btnDisplay
            // 
            this.btnDisplay.BackColor = System.Drawing.Color.Azure;
            this.btnDisplay.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnDisplay.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDisplay.ForeColor = System.Drawing.Color.Black;
            this.btnDisplay.Location = new System.Drawing.Point(236, 348);
            this.btnDisplay.Name = "btnDisplay";
            this.btnDisplay.Size = new System.Drawing.Size(120, 36);
            this.btnDisplay.TabIndex = 6;
            this.btnDisplay.Text = "Display";
            this.btnDisplay.UseVisualStyleBackColor = false;
            this.btnDisplay.Click += new System.EventHandler(this.btnDisplay_Click);
            // 
            // btnReturn
            // 
            this.btnReturn.BackColor = System.Drawing.Color.Azure;
            this.btnReturn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnReturn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReturn.ForeColor = System.Drawing.Color.Black;
            this.btnReturn.Location = new System.Drawing.Point(390, 348);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(120, 36);
            this.btnReturn.TabIndex = 7;
            this.btnReturn.Text = "Return";
            this.btnReturn.UseVisualStyleBackColor = false;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // Trainer_Feedback_page
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleTurquoise;
            this.ClientSize = new System.Drawing.Size(830, 456);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.btnDisplay);
            this.Controls.Add(this.txtFeedback);
            this.Controls.Add(this.cboTrainerName);
            this.Controls.Add(this.lblTrainerName);
            this.Controls.Add(this.lblTrainerFeedback);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Trainer_Feedback_page";
            this.Text = "Trainer_Feedback_page";
            this.Load += new System.EventHandler(this.Trainer_Feedback_page_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTrainerFeedback;
        private System.Windows.Forms.Label lblTrainerName;
        private System.Windows.Forms.ComboBox cboTrainerName;
        private System.Windows.Forms.TextBox txtFeedback;
        private System.Windows.Forms.Button btnDisplay;
        private System.Windows.Forms.Button btnReturn;
    }
}
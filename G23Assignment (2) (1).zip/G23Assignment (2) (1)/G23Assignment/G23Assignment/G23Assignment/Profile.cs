﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace G23Assignment
{
    public partial class Profile : Form
    {
        public static string name;
        public Profile()
        {
            InitializeComponent();
        }

        public Profile(string n)
        {
            InitializeComponent();
            name = n;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lblContact_Click(object sender, EventArgs e)
        {

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Lecturer obj1 = new Lecturer(Name);
            MessageBox.Show(obj1.UpdateProfile(txtUsername1.Text, txtEmail.Text, txtPhoneNumber.Text, txtPassword.Text));
        }

        private void Profile_Load(object sender, EventArgs e)
        {
           

        }



        private void btnCancel_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

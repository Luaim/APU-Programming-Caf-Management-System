﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace G23Assignment
{
    internal class Student
    {
        private string RequestStatus;
        private double Price;
        private string ModuleRequest;
        private int StudentID;
        private string Name;
        private string Email;
        private string Password;
        private string PhoneNumber;
        private string PaymentStatus;
        private string Module;
        private string Level;
        private float Charges;
        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());

        public int StudentID1 { get => StudentID; set => StudentID = value; }
        public string Name1 { get => Name; set => Name = value; }
        public string Email1 { get => Email; set => Email = value; }
        public string Password1 { get => Password; set => Password = value; }
        public string PhoneNumber1 { get => PhoneNumber; set => PhoneNumber = value; }
        public string PaymentStatus1 { get => PaymentStatus; set => PaymentStatus = value; }
        public string Module1 { get => Module; set => Module = value; }
        public string Level1 { get => Level; set => Level = value; }
        public float Charges1 { get => Charges; set => Charges = value; }
        public string ModuleRequest1 { get => ModuleRequest; set => ModuleRequest = value; }
        public string RequestStatus1 { get => RequestStatus; set => RequestStatus = value; }
        public double Price1 { get => Price; set => Price = value; }

        public Student(string N, string E, string P, string PN, string PS,string M, string L, int SID) 
        {
            StudentID1 = SID;
            Name1 = N;
            Email1 = E;
            Password1 = P;
            PhoneNumber1 = PN;
            PaymentStatus1 = PS;
            Module1 = M;
            Level1 = L;

        }


        public Student(string M, string L, string RS)
        {
            
            Email = M;
            Level = L;
            RequestStatus = RS;
        }

        

        public Student(string n )
        {
            Name = n;
        }


        
        public static void ShowProfile(Student S)
        {
            string status;
            con.Open();

            SqlCommand cmd = new SqlCommand("select * from Student where Name = '" + S.Name + "'", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                
                S.Name1 = rd.GetString(2); // Name  
                S.Email1 = rd.GetString(3); // Email    
                S.Password1 = rd.GetString(4); // Password  
                S.PhoneNumber1 = rd.GetString(5); // Phone Number
            }
            con.Close();

        }


        public string UpdateProfile(string N, string E, string P, string PN, int SID)
        {
            string status;
            con.Open();


            StudentID = SID;
            Name = N;
            Email1 = E;
            Password1 = P;
            PhoneNumber1 = PN;

            SqlCommand cmd = new SqlCommand("update Student set Email = @a, PhoneNumber = @b, Password = @c where Name = @d", con);
            cmd.Parameters.AddWithValue("@a", Email); ;
            cmd.Parameters.AddWithValue("@b", PhoneNumber);
            cmd.Parameters.AddWithValue("@c", Password);
            cmd.Parameters.AddWithValue("@d", Name);

            SqlCommand cmd2 = new SqlCommand("update Users set Email = @f, Password = @h   where Name = @g", con);
            cmd2.Parameters.AddWithValue("@f", Email);
            cmd2.Parameters.AddWithValue("@g", Name);
            cmd2.Parameters.AddWithValue("@h", Password);


            cmd2.ExecuteNonQuery();
            int i = cmd.ExecuteNonQuery();
            if (i != 0)
            {
                status = "Update Successfully.";
            }
            else
            {
                status = "Unable to update.";
            }
            con.Close();

            return status;
        }


        public static ArrayList StudentSchedule() 
        {
            con.Open();
            ArrayList S = new ArrayList();

            SqlCommand cmd = new SqlCommand("select * from Schedule", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                
                string level = rd.GetString(1);
                string module = rd.GetString(2);
                string time = rd.GetString(3);
                string date = rd.GetString(4);
                 
                string schedule =        level + "                   " + module + "                      " + time + "                        " + date;
                S.Add(schedule);

            }
            con.Close();
            return S;
        }



      


        public string StudentRequest( string M, string L, string RS)
        {

            string status;
            con.Open();


            
            Module = M;
            Level = L;
            RequestStatus = RS;



            SqlCommand cmd = new SqlCommand("insert into Request(StudentName,Level,Module,RequestStatus) values(@name, @lev, @mre, 'Pending')", con);


            int i = cmd.ExecuteNonQuery();
            if (i != 0)
            {
                status = "Request Successfully.";
            }
            else
            {
                status = "Unable to request.";
            }
               
            con.Close();
            return status;
  
        }

        public string RequestStatusUpdate()
        {
            string status;
            con.Open();

            SqlCommand cmd = new SqlCommand("update Request set RequestStatus='Deleted' where StudentName = @d", con);

            cmd.Parameters.AddWithValue("@d", Name);

            int x = cmd.ExecuteNonQuery();
            if(x != 0)
            {
                status = "Succefuly Deleted";
            }
            else
            {
                status = "Deletion error.";
            }
            con.Close();

            return status;
        }





        public static void Fees(Student S)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from Fees where StudentName '" + S.Name + "'", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                S.Module = rd.GetString(2);
                S.Charges = rd.GetInt32(3);
                S.PaymentStatus = rd.GetString(4);
            }
            con.Close();
        }

        public string FeesUpdate() 
        {
            string status;
            con.Open();

            SqlCommand cmd = new SqlCommand("update Fees set PaymentStatus = 'True' where StudentName = @a, ", con);
            cmd.Parameters.AddWithValue("@a", Name);

            int x = cmd.ExecuteNonQuery();
            if(x != 0)
            {
                status = "Paid succefully";
            }
            else
            {
                status = "Unsucceful Payment";
            }
            con.Close();
            return status;


        }


        



    }
}

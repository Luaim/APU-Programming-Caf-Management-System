﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace G23Assignment
{
    public partial class frmClassSchedule : Form
    {
        public static string Name;
        public frmClassSchedule()
        {
            InitializeComponent();
        }
        public frmClassSchedule(string n)
        {
            Name = n;
        }

        private void frmClassSchedule_Load(object sender, EventArgs e)
        {
            ArrayList schedules = Student.StudentSchedule();

            foreach (var schedule in schedules)
            {
                lstSchedule.Items.Add(schedule);
            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Close();
            frmStudentHomePage f1 = new frmStudentHomePage(Name);
            f1.ShowDialog();
        }

        private void lstSchedule_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}

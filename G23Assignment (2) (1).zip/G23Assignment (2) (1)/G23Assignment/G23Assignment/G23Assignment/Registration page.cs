﻿using G23Assignment.G23Assignment;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace G23Assignment
{
    public partial class Registration_page : Form
    {
        public Registration_page(string N)
        {
            InitializeComponent();
            Name = N;
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            //string Name = "luai";
            this.Close();

            Admin_Homepage ah = new Admin_Homepage(Name);
            ah.Show();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            string gender = rbMale.Checked ? "Male" : "Female";
            string modules = "";
            foreach (Control c in gbModules.Controls)
            {
                if (c is CheckBox)
                {
                    CheckBox cb = (CheckBox)c;
                    if (cb.Checked)
                    {
                        modules += cb.Text + " ";
                    }
                }
            }
            Admin admin = new Admin(
                txtName.Text, txtEmail.Text, txtPassword.Text, txtPhoneNumber.Text,
                gender, txtDateOfBirth.Text, cboTrainingLevel.Text, modules);
            MessageBox.Show(admin.Register());
        }
    }
}

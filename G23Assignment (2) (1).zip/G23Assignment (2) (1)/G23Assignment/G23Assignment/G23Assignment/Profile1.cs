﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace G23Assignment
{
    public partial class frmProfile : Form
    {

        int ThisStudentID;
        public static string Name;
        public frmProfile(string n)
        {
            InitializeComponent();
            Name = n;
        }

        private void frmProfile_Load(object sender, EventArgs e)
        {
            Student S = new Student(Name);

            Student.ShowProfile(S);

            txtName.Text = S.Name1;
            txtEmail.Text = S.Email1;
            txtPassword.Text = S.Password1;
            txtPhoneNumber.Text = S.PhoneNumber1;
            ThisStudentID = S.StudentID1;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Student S = new Student(Name);
            MessageBox.Show(S.UpdateProfile(txtName.Text, txtEmail.Text, txtPassword.Text, txtPhoneNumber.Text, ThisStudentID));
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            
            frmStudentHomePage f1 = new frmStudentHomePage(Name);
            f1.Show();
        }

        private void frmProfile_Load_1(object sender, EventArgs e)
        {

        }
    }
}

﻿namespace G23Assignment
{
    partial class frmStudentHomePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblStudentHP = new System.Windows.Forms.Label();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.btnProfile = new System.Windows.Forms.Button();
            this.btnFees = new System.Windows.Forms.Button();
            this.btnClassSchedule = new System.Windows.Forms.Button();
            this.btnClassRequest = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblStudentHP
            // 
            this.lblStudentHP.AutoSize = true;
            this.lblStudentHP.BackColor = System.Drawing.Color.Transparent;
            this.lblStudentHP.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStudentHP.Location = new System.Drawing.Point(292, 38);
            this.lblStudentHP.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblStudentHP.Name = "lblStudentHP";
            this.lblStudentHP.Size = new System.Drawing.Size(226, 33);
            this.lblStudentHP.TabIndex = 0;
            this.lblStudentHP.Text = "Student HomePage";
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcome.Location = new System.Drawing.Point(504, 113);
            this.lblWelcome.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(0, 22);
            this.lblWelcome.TabIndex = 1;
            // 
            // btnProfile
            // 
            this.btnProfile.BackColor = System.Drawing.Color.AliceBlue;
            this.btnProfile.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProfile.Location = new System.Drawing.Point(201, 147);
            this.btnProfile.Name = "btnProfile";
            this.btnProfile.Size = new System.Drawing.Size(120, 36);
            this.btnProfile.TabIndex = 2;
            this.btnProfile.Text = "Profile";
            this.btnProfile.UseVisualStyleBackColor = false;
            this.btnProfile.Click += new System.EventHandler(this.btnProfile_Click);
            // 
            // btnFees
            // 
            this.btnFees.BackColor = System.Drawing.Color.AliceBlue;
            this.btnFees.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFees.Location = new System.Drawing.Point(201, 277);
            this.btnFees.Name = "btnFees";
            this.btnFees.Size = new System.Drawing.Size(120, 36);
            this.btnFees.TabIndex = 3;
            this.btnFees.Text = "Fees";
            this.btnFees.UseVisualStyleBackColor = false;
            this.btnFees.Click += new System.EventHandler(this.btnFees_Click);
            // 
            // btnClassSchedule
            // 
            this.btnClassSchedule.BackColor = System.Drawing.Color.AliceBlue;
            this.btnClassSchedule.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClassSchedule.Location = new System.Drawing.Point(486, 147);
            this.btnClassSchedule.Name = "btnClassSchedule";
            this.btnClassSchedule.Size = new System.Drawing.Size(120, 36);
            this.btnClassSchedule.TabIndex = 4;
            this.btnClassSchedule.Text = "Class Schedule";
            this.btnClassSchedule.UseVisualStyleBackColor = false;
            this.btnClassSchedule.Click += new System.EventHandler(this.btnClassSchedule_Click);
            // 
            // btnClassRequest
            // 
            this.btnClassRequest.BackColor = System.Drawing.Color.AliceBlue;
            this.btnClassRequest.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClassRequest.Location = new System.Drawing.Point(486, 265);
            this.btnClassRequest.Name = "btnClassRequest";
            this.btnClassRequest.Size = new System.Drawing.Size(120, 36);
            this.btnClassRequest.TabIndex = 5;
            this.btnClassRequest.Text = "ClassRequest";
            this.btnClassRequest.UseVisualStyleBackColor = false;
            this.btnClassRequest.Click += new System.EventHandler(this.btnClassRequest_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnLogout.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout.Location = new System.Drawing.Point(673, 416);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(120, 36);
            this.btnLogout.TabIndex = 6;
            this.btnLogout.Text = "Log out";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // frmStudentHomePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(15F, 30F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::G23Assignment.Properties.Resources.c_71;
            this.ClientSize = new System.Drawing.Size(833, 494);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.btnClassRequest);
            this.Controls.Add(this.btnClassSchedule);
            this.Controls.Add(this.btnFees);
            this.Controls.Add(this.btnProfile);
            this.Controls.Add(this.lblWelcome);
            this.Controls.Add(this.lblStudentHP);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(6);
            //this.Name = "frmStudentHomePage";
            this.Text = "frmStudentHomePage";
            this.Load += new System.EventHandler(this.frmStudentHomePage_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblStudentHP;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Button btnProfile;
        private System.Windows.Forms.Button btnFees;
        private System.Windows.Forms.Button btnClassSchedule;
        private System.Windows.Forms.Button btnClassRequest;
        private System.Windows.Forms.Button btnLogout;
    }
}
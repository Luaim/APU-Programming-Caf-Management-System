﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace G23Assignment
{
    internal class Trainer
    {
        private int TrainerID;
        private string Name;
        private string Email;
        private string Password;
        private string PhoneNumber;
        private string DateOfBirth;
        private string Gender;
        private string TrainingLevel;
        private string Module;
        private string Charges;
        private string ClassSchedule;
        private string MonthlyIncome;
        private string Feedback;
        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());

        public int TrainerID0 { get => TrainerID0; set => TrainerID0 = value; }
        public string Name0 { get => Name; set => Name = value; }
        public string Email0 { get => Email; set => Email = value; }
        public string Password0 { get => Password; set => Password = value; }
        public string PhoneNumber0 { get => PhoneNumber; set => PhoneNumber = value; }
        public string Gender0 { get => Gender; set => Gender = value; }
        public string DateOfBirth0 { get => DateOfBirth; set => DateOfBirth = value; }
        public string TrainingLevel0 { get => TrainingLevel; set => TrainingLevel = value; }
        public string Module0 { get => Module; set => Module = value; }
        public string Charges0 { get => Charges; set => Charges = value; }
        public string ClassSchedule0 { get => ClassSchedule; set => ClassSchedule = value; }
        public string MonthlyIncome0 { get => MonthlyIncome; set => MonthlyIncome = value; }
        public string Feedback0 { get => Feedback; set => Feedback = value; }

        public Trainer(string N, string E, string P, string PN, string g, string DOB, string tl, string m, string Ch, string Cs, string Mi, string Fb)
        {
            Name0 = N;
            Email0 = E;
            Password0 = P;
            PhoneNumber0 = PN;
            Gender0 = g;
            DateOfBirth0 = DOB;
            TrainingLevel0 = tl;
            Module0 = m;
            Charges0 = Ch;
            ClassSchedule0 = Cs;
            MonthlyIncome0 = Mi;
            Feedback0 = Fb;
        }

        public Trainer(string N)
        {
            Name0 = N;
        }

        public static void ShowProfile(Trainer S)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from Trainer where Email = @Name", con);
            cmd.Parameters.AddWithValue("@Name", S.Name);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())

            {
                S.TrainerID = rd.GetInt32(0);
                S.Name0 = rd.GetString(1); // Name  
                S.Email0 = rd.GetString(2); // Email    
                S.Password0 = rd.GetString(3); // Password  
                S.PhoneNumber0 = rd.GetString(4); // Phone Number
            }
            con.Close();
        }
        public string UpdateProfile(String N, String E, String P, String PN, int SI)
        {
            string status;
            con.Open();

            Name = N;
            Email = E;
            Password = P;
            PhoneNumber = PN;
            TrainerID = SI;
            //update trainer table
            SqlCommand cmd = new SqlCommand("update Trainer set Email = @a,PhoneNumber = @b, Password = @c where Name = @d", con);
            cmd.Parameters.AddWithValue("@a", Email); ;
            cmd.Parameters.AddWithValue("@b", PhoneNumber);
            cmd.Parameters.AddWithValue("@c", Password);
            cmd.Parameters.AddWithValue("@d", Name);

            SqlCommand cmd2 = new SqlCommand("update Users set Email = @f, Password = @h   where Name = @g", con);
            cmd2.Parameters.AddWithValue("@f", Email);
            cmd2.Parameters.AddWithValue("@g", Name);
            cmd2.Parameters.AddWithValue("@h", Password);

            cmd2.ExecuteNonQuery();
            int i = cmd.ExecuteNonQuery();
            if (i != 0)
            {
                status = "Update Successfully.";
            }
            else
            {
                status = "Unable to update.";
            }
            con.Close();

            return status;
        }

        }
    }

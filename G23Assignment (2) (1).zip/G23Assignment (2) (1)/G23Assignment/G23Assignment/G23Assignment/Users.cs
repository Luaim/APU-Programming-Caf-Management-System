﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace G23Assignment
{
    class Users
    {
        private string Email;
        private string Password;

        // Login method for users
        public Users(string E, string p)
        {
            Email = E;
            Password = p;
        }

        public string Login(string un)
        {
            string status = null;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());
            con.Open();

            // Check if the user exists in the database
            SqlCommand cmd = new SqlCommand("Select count(*) from users where Email=@Email and Password=@Password", con);
            cmd.Parameters.AddWithValue("@Email", Email);
            cmd.Parameters.AddWithValue("@Password", Password);

            int count = Convert.ToInt32(cmd.ExecuteScalar().ToString());

            if (count > 0) // Get the role of the user
            {
                SqlCommand cmd2 = new SqlCommand("Select role from users where Email=@Email and Password=@Password", con);
                cmd2.Parameters.AddWithValue("@Email", Email);
                cmd2.Parameters.AddWithValue("@Password", Password);

                string userRole = cmd2.ExecuteScalar().ToString();

                if (userRole == "Admin") // Open admin homepage
                {
                    Admin_Homepage a = new Admin_Homepage(un);
                    a.ShowDialog();
                    con.Close();
                    return null;
                }
                else if(userRole == "Trainer") // open the trainer hompage
                {
                    TrainerHomepage t = new TrainerHomepage();
                    t.ShowDialog();
                    con.Close();
                    return null;
                }
                else if (userRole == "Lecturer") //Open Lecturer homepage
                {
                  Homepage H = new Homepage(un);
                  H.ShowDialog();
                  con.Close();
                  return null;
                }
                else if (userRole == "Student") // open Student homepage
                {
                    frmStudentHomePage S = new frmStudentHomePage(un);
                    S.ShowDialog();
                    con.Close();
                    return null;
                }
            }
            else
                status = "Login failed. Please check your Email and password.";

            con.Close();

            return status;
        }
    }

}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace G23Assignment
{
    public partial class frmLogin : Form
    {
        private bool passwordVisible;
        public frmLogin()
        {
            InitializeComponent();
            passwordVisible = false;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            this.Hide();
            string stat;
            Users obj1 = new Users(txtEmail.Text, txtPassword.Text);
            stat = obj1.Login(txtEmail.Text);
            if (stat != null)
            {
                MessageBox.Show(stat);
                this.Show();
            }
            txtEmail.Text = String.Empty;
            txtPassword.Text = String.Empty;
            
        }
      
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            passwordVisible = !passwordVisible; 

            if (passwordVisible)
            {
                txtPassword.UseSystemPasswordChar = false; 
            }
            else
            {
                txtPassword.UseSystemPasswordChar = true;
            }
        }

        private void lblEmail_Click(object sender, EventArgs e)
        {

        }
    }
}

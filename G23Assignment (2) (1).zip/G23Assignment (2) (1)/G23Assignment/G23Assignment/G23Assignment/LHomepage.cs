﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace G23Assignment
{
    public partial class Homepage : Form
    {
        public static string name; //global declaration; static- will hold value until program is terminated
        
        public Homepage()
        {
            InitializeComponent();
        }
        
        public Homepage(string n)
        { 
            InitializeComponent();
            name = n;
        }

        private void label1_Click(object sender, EventArgs e)
        {
            //lblIdentity.Text = "Lecturer Homepage" //for displaying the role on the form
                //Add it in the user class and make sure the constructor also receive it and assign a value to it
        }
        
        private void btnProfile_Click(object sender, EventArgs e)
        {
            Profile pr = new Profile();
            pr.ShowDialog();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            Registration rs = new Registration();
            rs.ShowDialog(); 
        }

        private void btnRequest_Click(object sender, EventArgs e)
        {
            Requests rq = new Requests();
            rq.ShowDialog();
        }

        private void btnStudents_Click(object sender, EventArgs e)
        {
            Listofstudents Los = new Listofstudents();
            Los.ShowDialog();
        }

        private void Homepage_Load(object sender, EventArgs e)
        {
        }
        private void Homepage_Load_1(object sender, EventArgs e)
        {  
        }

        private void Homepage_Load_2(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Deletestudents d = new Deletestudents();
            d.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();

            frmLogin fr = new frmLogin();// Open the login form
            fr.Show();
        }
    }
}

﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace G23Assignment
{
    public partial class Listofstudents : Form

    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());
        public Listofstudents()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Listofstudents_Load(object sender, EventArgs e)
        {
            ArrayList name = new ArrayList();

            name = students.ListofStudents();
            foreach (var item in name) 
            {
                lstName.Items.Add(item);               
            }

            string[] values = { "Beginner", "Intermediate", "Advanced" };

            // Iterate over the values and add them to the ListBox
            foreach (string value in values)
            {
                lstLevel.Items.Add(value);
            }
        }

        private void lstName_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lstLevel_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnUpdLvl_Click(object sender, EventArgs e)
        {
            students obj1 = new students(lstName.SelectedItems.ToString(),lstLevel.SelectedItem.ToString());
            MessageBox.Show(obj1.UpdLvl(lstName,lstLevel));

            
            lstName.Items.Remove(lstName.SelectedItem);

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

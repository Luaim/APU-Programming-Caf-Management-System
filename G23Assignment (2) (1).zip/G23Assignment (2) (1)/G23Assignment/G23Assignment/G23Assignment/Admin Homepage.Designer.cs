﻿namespace G23Assignment
{
    partial class Admin_Homepage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAdminHomepage = new System.Windows.Forms.Label();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.btnProfile = new System.Windows.Forms.Button();
            this.btnIncomeReport = new System.Windows.Forms.Button();
            this.btnRegister = new System.Windows.Forms.Button();
            this.btnTrainerFeedback = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnDeleteTrainer = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblAdminHomepage
            // 
            this.lblAdminHomepage.AutoSize = true;
            this.lblAdminHomepage.BackColor = System.Drawing.Color.Transparent;
            this.lblAdminHomepage.Font = new System.Drawing.Font("Times New Roman", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdminHomepage.Location = new System.Drawing.Point(292, 38);
            this.lblAdminHomepage.Name = "lblAdminHomepage";
            this.lblAdminHomepage.Size = new System.Drawing.Size(240, 34);
            this.lblAdminHomepage.TabIndex = 0;
            this.lblAdminHomepage.Text = "Admin Homepage";
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.BackColor = System.Drawing.Color.Transparent;
            this.lblWelcome.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblWelcome.ForeColor = System.Drawing.Color.Black;
            this.lblWelcome.Location = new System.Drawing.Point(319, 87);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(2, 24);
            this.lblWelcome.TabIndex = 1;
            // 
            // btnProfile
            // 
            this.btnProfile.BackColor = System.Drawing.Color.AliceBlue;
            this.btnProfile.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnProfile.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProfile.ForeColor = System.Drawing.Color.Black;
            this.btnProfile.Location = new System.Drawing.Point(201, 147);
            this.btnProfile.Name = "btnProfile";
            this.btnProfile.Size = new System.Drawing.Size(120, 36);
            this.btnProfile.TabIndex = 6;
            this.btnProfile.Text = "Profile";
            this.btnProfile.UseVisualStyleBackColor = false;
            this.btnProfile.Click += new System.EventHandler(this.btnProfile_Click);
            // 
            // btnIncomeReport
            // 
            this.btnIncomeReport.BackColor = System.Drawing.Color.AliceBlue;
            this.btnIncomeReport.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnIncomeReport.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIncomeReport.ForeColor = System.Drawing.Color.Black;
            this.btnIncomeReport.Location = new System.Drawing.Point(201, 228);
            this.btnIncomeReport.Name = "btnIncomeReport";
            this.btnIncomeReport.Size = new System.Drawing.Size(120, 36);
            this.btnIncomeReport.TabIndex = 7;
            this.btnIncomeReport.Text = "Income Report";
            this.btnIncomeReport.UseVisualStyleBackColor = false;
            this.btnIncomeReport.Click += new System.EventHandler(this.btnIncomeReport_Click);
            // 
            // btnRegister
            // 
            this.btnRegister.BackColor = System.Drawing.Color.AliceBlue;
            this.btnRegister.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnRegister.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegister.ForeColor = System.Drawing.Color.Black;
            this.btnRegister.Location = new System.Drawing.Point(472, 147);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(120, 36);
            this.btnRegister.TabIndex = 8;
            this.btnRegister.Text = "Registration";
            this.btnRegister.UseVisualStyleBackColor = false;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // btnTrainerFeedback
            // 
            this.btnTrainerFeedback.BackColor = System.Drawing.Color.AliceBlue;
            this.btnTrainerFeedback.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnTrainerFeedback.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTrainerFeedback.ForeColor = System.Drawing.Color.Black;
            this.btnTrainerFeedback.Location = new System.Drawing.Point(472, 228);
            this.btnTrainerFeedback.Name = "btnTrainerFeedback";
            this.btnTrainerFeedback.Size = new System.Drawing.Size(120, 36);
            this.btnTrainerFeedback.TabIndex = 9;
            this.btnTrainerFeedback.Text = "Trainer Feedback";
            this.btnTrainerFeedback.UseVisualStyleBackColor = false;
            this.btnTrainerFeedback.Click += new System.EventHandler(this.btnTrainerFeedback_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnLogout.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnLogout.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout.ForeColor = System.Drawing.Color.Black;
            this.btnLogout.Location = new System.Drawing.Point(673, 416);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(120, 36);
            this.btnLogout.TabIndex = 10;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // btnDeleteTrainer
            // 
            this.btnDeleteTrainer.BackColor = System.Drawing.Color.AliceBlue;
            this.btnDeleteTrainer.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnDeleteTrainer.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteTrainer.ForeColor = System.Drawing.Color.Black;
            this.btnDeleteTrainer.Location = new System.Drawing.Point(339, 299);
            this.btnDeleteTrainer.Name = "btnDeleteTrainer";
            this.btnDeleteTrainer.Size = new System.Drawing.Size(120, 36);
            this.btnDeleteTrainer.TabIndex = 11;
            this.btnDeleteTrainer.Text = "Delete Trainer";
            this.btnDeleteTrainer.UseVisualStyleBackColor = false;
            this.btnDeleteTrainer.Click += new System.EventHandler(this.btnDeleteTrainer_Click);
            // 
            // Admin_Homepage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.BackgroundImage = global::G23Assignment.Properties.Resources.c_71;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(833, 494);
            this.Controls.Add(this.btnDeleteTrainer);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.btnTrainerFeedback);
            this.Controls.Add(this.btnRegister);
            this.Controls.Add(this.btnIncomeReport);
            this.Controls.Add(this.btnProfile);
            this.Controls.Add(this.lblWelcome);
            this.Controls.Add(this.lblAdminHomepage);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Admin_Homepage";
            this.Text = " Admin_Homepage";
            this.Load += new System.EventHandler(this.Admin_Homepage_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAdminHomepage;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Button btnProfile;
        private System.Windows.Forms.Button btnIncomeReport;
        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.Button btnTrainerFeedback;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button btnDeleteTrainer;
    }
}
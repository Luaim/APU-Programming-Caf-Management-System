﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Xml.Linq;
using System.Data.SqlClient;

namespace G23Assignment
{
    using System;
    using System.Collections;
    using System.Data.SqlClient;
    using System.Configuration;
    using System.Windows.Forms;
    using System.Globalization;

    namespace G23Assignment
    {
        class Admin
        {
            // Private fields
            private int AdminID;
            private string Name;
            private string Email;
            private string Password;
            private string PhoneNumber;
            private string DateOfBirth;
            private string Gender;
            private string TrainingLevel;
            private string Module;
            static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());

            // Properties
            public string Email1 { get => Email; set => Email = value; }
            public string Name1 { get => Name; set => Name = value; }
            public string Password1 { get => Password; set => Password = value; }
            public string PhoneNumber1 { get => PhoneNumber; set => PhoneNumber = value; }
            public string Gender1 { get => Gender; set => Gender = value; }
            public string DateOfBirth1 { get => DateOfBirth; set => DateOfBirth = value; }
            public string TrainingLevel1 { get => TrainingLevel; set => TrainingLevel = value; }
            public string Module1 { get => Module; set => Module = value; }
            public int AdminID1 { get => AdminID; set => AdminID = value; }

            // Constructor
            public Admin(string N, string E, string P, string PN, string g, string DOB, string tl, string m)
            {
                Name1 = N;
                Email1 = E;
                Password1 = P;
                PhoneNumber1 = PN;
                Gender1 = g;
                DateOfBirth1 = DOB;
                TrainingLevel1 = tl;
                Module1 = m;
            }

            public Admin(string N) // Constructor with only name parameter
            {
                Name = N;
            }

            public string Register() // Register method to create a new trainer
            {
                string status;
                con.Open();

                // Insert into 'users' table
                SqlCommand cmd2 = new SqlCommand("insert into users(Name,Email,Password,role) values(@Name,@Email,@Password,'Trainer')", con);
                cmd2.Parameters.AddWithValue("@Name", Name);
                cmd2.Parameters.AddWithValue("@Email", Email);
                cmd2.Parameters.AddWithValue ("Password", Password);

                cmd2.ExecuteNonQuery();

                // Insert into 'Trainer' table
                SqlCommand cmd = new SqlCommand("insert into Trainer(Name,Email,Password,PhoneNumber,Gender,DateOfBirth,TrainingLevel,Module) Values(@Name,@Email,@Password,@PhoneNumber,@Gender,@DateOfBirth,@TrainingLevel,@Module)", con);
                cmd.Parameters.AddWithValue("@Name", Name);
                cmd.Parameters.AddWithValue("@Email", Email);
                cmd.Parameters.AddWithValue("@Password", Password);
                cmd.Parameters.AddWithValue("@PhoneNumber", PhoneNumber);
                cmd.Parameters.AddWithValue("@Gender", Gender);
                cmd.Parameters.AddWithValue("@DateOfBirth", DateOfBirth);
                cmd.Parameters.AddWithValue("@TrainingLevel", TrainingLevel);
                cmd.Parameters.AddWithValue("@Module", Module);

                int i = cmd.ExecuteNonQuery();

                if (i != 0)
                {
                    status = "Registration Completed Successfully.";
                }
                else
                {
                    status = "Registration Failed.";
                }
                con.Close();
                return status;
            }


            public static List<String> ViewAll() // View all trainers' names
            {
                List<String> names = new List<String>();
                con.Open();

                SqlCommand cmd = new SqlCommand("select Name from Trainer", con);
                SqlDataReader rd = cmd.ExecuteReader();

                while (rd.Read())
                {
                    names.Add(rd.GetString(0));
                }
                con.Close();
                return names;
            }


            public void ViewProfile(Admin A) // View the profile of a specific admin
            {
                con.Open();

                SqlCommand cmd = new SqlCommand("Select * from Adminstrator where Email = @Name", con);
                cmd.Parameters.AddWithValue("@Name", A.Name);
                SqlDataReader rd = cmd.ExecuteReader();

                while (rd.Read())
                {
                    A.AdminID = rd.GetInt32(0);
                    A.Name1 = rd.GetString(1);
                    A.Email1 = rd.GetString(2);
                    A.Password1 = rd.GetString(3);
                    A.PhoneNumber1 = rd.GetString(4);
                }
                con.Close();
            }

            // Update the profile of an admin
            public string UpdateProfile(string N, string em, string P, string num, int ID)
            {
                string status;
                con.Open();

                Name = N;
                Email = em;
                Password = P;
                PhoneNumber = num;
                AdminID = ID;

                // Update 'Adminstrator' table
                SqlCommand cmd = new SqlCommand("update Adminstrator set Email='" + Email + "',PhoneNumber='" + PhoneNumber + "', Password='" + Password + "', Name ='" + Name +  "' Where AdminID ='" + AdminID + "'", con);
               
                // Update 'users' table
                SqlCommand cmd1 = new SqlCommand("update users set Email='" + Email + "', Password='" + Password + "', Name ='" + Name + "' Where userID ='" + AdminID + "'", con);
              
                 int i = cmd.ExecuteNonQuery();
                 int u = cmd1.ExecuteNonQuery();
                 if (i != 0 && u != 0)
                 {
                    status = "Update Successfully.";
                 }
                 else
                 {
                    status = "Unable to update.";
                 }
               
                con.Close();
                return status;
            }
            // Calculate monthly income for a trainer based on name, training level, and module
            public static decimal MonthlyIncome(Admin admin, out string incomeReport)
            {
                decimal monthlyIncome = 0;
                incomeReport = "";

                string query = "SELECT MonthlyIncome FROM Trainer WHERE Name = @Name AND TrainingLevel = @TrainingLevel AND Module = @Module";

                using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ConnectionString))
                {
                    con.Open();

                    SqlCommand command = new SqlCommand(query, con);
                    command.Parameters.AddWithValue("@Name", admin.Name1);
                    command.Parameters.AddWithValue("@TrainingLevel", admin.TrainingLevel1);
                    command.Parameters.AddWithValue("@Module", admin.Module1);

                    object result = command.ExecuteScalar();

                    if (result != null && decimal.TryParse(result.ToString(), out monthlyIncome))
                    {
                        incomeReport = $"The income for this month in {admin.Module1} for trainer {admin.Name1} for level {admin.TrainingLevel1} is RM {monthlyIncome.ToString()}";
                    }
                    else
                    {
                        incomeReport = "Unable to retrieve monthly income.";
                    }

                    con.Close();
                }

                return monthlyIncome;
            }
            public static List<string> GetLevel() // Get training levels from the Trainer table
            {
                List<string> trainingLevels = new List<string>();
                string connectionString = ConfigurationManager.ConnectionStrings["myCS"].ConnectionString;

                SqlConnection connection = new SqlConnection(connectionString);
                if (connection != null)
                {
                    connection.Open();
                    string query = "SELECT DISTINCT TrainingLevel FROM Trainer";
                    SqlCommand command = new SqlCommand(query, connection);

                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        string trainingLevel = reader.GetString(0);
                        trainingLevels.Add(trainingLevel);
                    }

                    reader.Close();
                    connection.Close();
                }
                else
                {
                    Console.WriteLine("Error:");
                }

                return trainingLevels;
            }

            public static List<string> GetModule() // Get modules from the Trainer table
            {
                List<string> modules = new List<string>();
                string connectionString = ConfigurationManager.ConnectionStrings["myCS"].ConnectionString;

                SqlConnection connection = new SqlConnection(connectionString);
                if (connection != null)
                {
                    connection.Open();

                    string query = "SELECT DISTINCT Module FROM Trainer";
                    SqlCommand command = new SqlCommand(query, connection);

                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        string module = reader.GetString(0);
                        modules.Add(module);
                    }

                    reader.Close();
                    connection.Close();
                }
                else
                {
                    Console.WriteLine("Error");
                }

                return modules;
            }

            public static string GetTrainerFeedback(string trainerName) // Get trainer feedback based on trainer name
            {
                string feedback = "";
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ConnectionString);

                if (con != null)
                {
                    con.Open();

                    string query = "SELECT Feedback FROM Trainer WHERE Name = @Name";
                    SqlCommand command = new SqlCommand(query, con);
                    command.Parameters.AddWithValue("@Name", trainerName);

                    object result = command.ExecuteScalar();
                    if (result != null)
                    {
                        feedback = result.ToString();
                    }

                    con.Close();
                }
                else
                {
                    Console.WriteLine("Error ");
                }

                return feedback;

            }
        }
  
    }
    
}


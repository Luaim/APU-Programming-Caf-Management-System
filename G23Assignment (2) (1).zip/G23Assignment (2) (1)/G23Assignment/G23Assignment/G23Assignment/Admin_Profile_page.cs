﻿using G23Assignment.G23Assignment;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace G23Assignment
{
    public partial class Admin_Profile_page : Form
    {
        int Thisadminid;
        public static string Name;

        public Admin_Profile_page(string N)
        {
            InitializeComponent();
            Name = N;

        }
        // Event handler for clicking the "Return" button
        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Close();

            //string Name = "Luai";
            Admin_Homepage ah = new Admin_Homepage(Name);// Open the admin homepage form
            ah.ShowDialog();

        }

        private void Admin_Profile_page_Load(object sender, EventArgs e)
        {
            Admin A = new Admin(Name);
            A.ViewProfile(A);  // Call the ViewProfile method to get the admin's profile information

            // Display the profile information in the text boxes
            txtName.Text = A.Name1;
            txtEmail.Text = A.Email1;
            txtPassword.Text = A.Password1;
            txtPhoneNumber.Text = A.PhoneNumber1;
            Thisadminid = A.AdminID1;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Admin obj1 = new Admin(Name); // Call the UpdateProfile method to update the admin's profile information
            MessageBox.Show(obj1.UpdateProfile(txtName.Text, txtEmail.Text, txtPassword.Text, txtPhoneNumber.Text, Thisadminid));

        }
    }
}

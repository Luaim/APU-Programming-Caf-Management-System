﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Windows.Forms;
using System.Runtime.Remoting.Messaging;

namespace G23Assignment
{
    internal class Lecturer
    {
        private string lecturerName;
        private string email;
        private string password;
        private string phoneNumber;
        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());

        public string Email { get => email; set => email = value; }

        //public string ContNumber { get => contNumber; set => contNumber = value;}
        public string PhoneNumber { get => phoneNumber; set => phoneNumber = value; }
        public string LecturerName { get => lecturerName; set => lecturerName = value; }
        public string Password { get => password; set => password = value; }

        //public string Email { get => email; set => email = value; }
        //public string ContNumber { get => contNumber; set => contNumber = value; }

        public Lecturer(string ln)
        {
            lecturerName = ln;
        }



        public Lecturer(string ln, string e, string num, string p)
        {
            lecturerName = ln;         
            email = e;
            phoneNumber = num;
            password = p;
        }
       

        public Lecturer()
        {

        }

      
            
            

        public string UpdateProfile(string ln, string e, string num, string p)
        {
            string status;
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString()))
            {
                con.Open();

               

                SqlCommand cmd = new SqlCommand("UPDATE Lecturer SET Email = @Email, PhoneNumber = @PhoneNumber, Password = @Password WHERE LecturerName = @LecturerName", con);
                cmd.Parameters.AddWithValue("@Email", email);
                cmd.Parameters.AddWithValue("@PhoneNumber", phoneNumber);
                cmd.Parameters.AddWithValue("@Password", password);
                cmd.Parameters.AddWithValue("@LecturerName", lecturerName);

                               
                int rowsAffected = cmd.ExecuteNonQuery();
                if (rowsAffected > 0)
                    status = "Update successful.";
                else
                    status = "Update failed.";

                SqlCommand cmd2 = new SqlCommand("UPDATE Users SET Email = @Email, Password = @Password WHERE Name = @LecturerName", con);
                cmd2.Parameters.AddWithValue("@LecturerName", lecturerName);
                cmd2.Parameters.AddWithValue("@Password", password);
                cmd2.Parameters.AddWithValue("@Email", email);


                cmd2.ExecuteNonQuery();
                con.Close();

            }

            return status;
        }
    }
}

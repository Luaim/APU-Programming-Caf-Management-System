﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace G23Assignment
{
    public partial class CoachingClassinfo : Form
    {
        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());
        

        public CoachingClassinfo()
        {
            InitializeComponent();
           
        }

        private void lblCoachInfo_Click(object sender, EventArgs e)
        {

        }

        private void lblAddCoach_Click(object sender, EventArgs e)
        {

        }

        private void lblModuleName_Click(object sender, EventArgs e)
        {

        }

        private void lblModuleLevel_click(object sender, EventArgs e)
        {

        }

        private void lblCharges_click(object sender, EventArgs e)
        {

        }

        private void lblDate_Click(object sender, EventArgs e)
        {

        }

        private void Time_click(object sender, EventArgs e)
        {

        }

        private void txtModuleName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtModuleLevel_click(object sender, EventArgs e)
        {

        }

        private void txtModuleLevel_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtCharges_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtDate_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtTime_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblCoachList_click(object sender, EventArgs e)
        {

        }

        private void btnsubmit_click(object sender, EventArgs e)
        { 
            con.Open();
            SqlCommand cmd = new SqlCommand("INSERT INTO Student(Module,Level,Charges,Date,Time)values(@Module,@Level,@Charges,@Date,@Time)", con);
            cmd.Parameters.AddWithValue("@Module", txtModuleName.Text);
            cmd.Parameters.AddWithValue("@Level", txtModuleLevel.Text);
            cmd.Parameters.AddWithValue("@Charges", decimal.Parse(txtCharges.Text));
            cmd.Parameters.AddWithValue("@Date", DateTime.Parse(txtDate.Text));
            cmd.Parameters.AddWithValue("@Time", decimal.Parse(txtTime.Text));


            cmd.ExecuteNonQuery();

            con.Close();
            disp_data();
            MessageBox.Show("Successfully saved");

        }
        public void disp_data()
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select Name,Module,Level,Date,Time from Student";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            LstCoachingList.DataSource = dt;
            con.Close();
        }
        private void btnDisplay_Click(object sender, EventArgs e)
        {
            disp_data();
        }
        public void delete_data()
        {
            if (LstCoachingList.SelectedRows.Count == 0)
                return;


            string sql = "DELETE FROM TRAINER WHERE Module = @rowID";
            using (SqlConnection myConnection = new SqlConnection("Variable"))
            using (SqlCommand deleteRecord = new SqlCommand(sql, myConnection))
            {
                con.Open();
                int selectedIndex = LstCoachingList.SelectedRows[0].Index;
                int rowID = Convert.ToInt32(LstCoachingList[0, selectedIndex].Value);

                deleteRecord.Parameters.Add("@rowID", SqlDbType.Int).Value = rowID;
                deleteRecord.ExecuteNonQuery();

                LstCoachingList.Rows.RemoveAt(selectedIndex);

                con.Close();
            }
        }
        private void btndelete_click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow item in this.LstCoachingList.SelectedRows)
            {
                LstCoachingList.Rows.RemoveAt(item.Index);

                MessageBox.Show("Successfully deleted");
            }

        }

        private void btnreturn_Click(object sender, EventArgs e)
        {
            this.Hide();
            TrainerHomepage f1 = new TrainerHomepage();
            f1.Show();
        }

        private void LstCoachingList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

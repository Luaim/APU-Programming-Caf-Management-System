﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;
using System.Security.Cryptography.X509Certificates;
using System.Collections;

namespace G23Assignment
{
    internal class students
    {
        private string Studname;
        private string Email;
        private string phoneNumber;
        private string TPNumber;
        private string Level;
        private string Module;
        private DateTime EnrDate;
        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());

        public students(string s, string e, string num, string Tp, string lvl, string Mod, string d)
        {
            Studname = s;
            Email = e;
            phoneNumber = num;
            TPNumber = Tp;
            Level = lvl;
            Module = Mod;
            EnrDate = DateTime.Parse(d);
        }

        public students(string s)
        {
            Studname = s;

        }
        public students(string s,string l) 
        {
            Studname = s;
            Level = l;

        }
        public string RegisterStudents()
        {
            string status;
            con.Open();

            SqlCommand cmd = new SqlCommand("INSERT into Student(Name,email,phoneNumber,TPNumber,Level,Module,EnrollmentDate,RequestStatus) values(@name,@em,@num,@Tp,@lvl,@Mod,@date,'-')", con);
            cmd.Parameters.AddWithValue("@name", Studname);
            cmd.Parameters.AddWithValue("@em", Email);
            cmd.Parameters.AddWithValue("@num", phoneNumber);
            cmd.Parameters.AddWithValue("@Tp", TPNumber);
            cmd.Parameters.AddWithValue("@lvl", Level);
            cmd.Parameters.AddWithValue("@Mod", Module);
            cmd.Parameters.AddWithValue("@date", EnrDate);




            SqlCommand cmd2 = new SqlCommand("INSERT into Users(Name,email,password,Role) values(@name,@em,'123','student')", con);
            cmd2.Parameters.AddWithValue("@name", Studname);
            cmd2.Parameters.AddWithValue("@em", Email);

            cmd2.ExecuteNonQuery();
            int i = cmd.ExecuteNonQuery();
            if (i != 0)
                status = "Registration successful.";
            else
                status = "Registration failed.\t Try again. ";

            con.Close();

            return status;


        }

        public static ArrayList studentRequests()
        {
            ArrayList sr = new ArrayList();
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT Name FROM Student WHERE RequestStatus = 'Pending'", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                sr.Add(rd.GetString(0));
            }


            con.Close();
            return sr;
        }

        public string RequestStatus(ListBox lstName)
        {
            string status;
            con.Open();
            SqlCommand cmd = new SqlCommand("UPDATE Student SET RequestStatus = 'Approved' WHERE Name = @name", con);
            cmd.Parameters.AddWithValue("@name", lstName.SelectedItem.ToString());

            int r = cmd.ExecuteNonQuery();
            if (r != 0)
                status = "Updated successfully.";
            else
                status = "Unable to approve request.";
            con.Close();

            return status;
        }

        public static ArrayList ListofStudents()
        {
            ArrayList Los = new ArrayList();
            con.Open();
            SqlCommand cmd = new SqlCommand("Select Name From Student WHERE RequestStatus = 'Approved'", con);

            SqlDataReader rd = cmd.ExecuteReader();


            while (rd.Read())
            {
                Los.Add(rd.GetString(0));
            }

            con.Close();
            return Los;

        }

        public string UpdLvl(ListBox lstName, ListBox lstLevel)
        {
            string status;
            con.Open();

            SqlCommand cmd = new SqlCommand("UPDATE Student SET Level = @Level WHERE Name = @Name", con);
            cmd.Parameters.AddWithValue("@Level", lstLevel.SelectedItem.ToString());
            cmd.Parameters.AddWithValue("@Name", lstName.SelectedItem.ToString());

            int r = cmd.ExecuteNonQuery();
            if (r != 0)
                status = "Level updated successfully.";
            else
                status = "Unable to update.";
            con.Close();

            return status;

        }
        public static ArrayList DelStud()
        {
            ArrayList lstStud = new ArrayList();
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT Name FROM Student WHERE Progress = '100'", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read()) 
            {
                lstStud.Add(rd.GetString(0));
            }
            con.Close() ;
            return lstStud;
        }

        public string DelBtn(ListBox lstName1) 
        {
            string status;
            con.Open() ;
            SqlCommand cmd = new SqlCommand("DELETE FROM Student WHERE Progress = '100'", con);
            int r = cmd.ExecuteNonQuery();
            if (r != 0)
                status = "Record deleted successfully.";
            else
                status = "Process failed.";
            con.Close(); 
            return status;
        }

    }  



}










    


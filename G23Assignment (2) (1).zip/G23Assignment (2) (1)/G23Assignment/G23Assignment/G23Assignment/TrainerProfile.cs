﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace G23Assignment
{
    public partial class TrainerProfile : Form
    {
        int ThisTrainerid;
        public static string Name;

        public TrainerProfile()
        {
            InitializeComponent();
        }
        public TrainerProfile(string n)
        {
            InitializeComponent();
            Name = n;

        }
        private void TrainerProfile_Load(object sender, EventArgs e)
        {
            Trainer S = new Trainer(Name);
            Trainer.ShowProfile(S);

            txtName.Text = S.Name0;
            txtEmail.Text = S.Email0;
            txtPassword.Text = S.Password0;
            txtPhoneNum.Text = S.PhoneNumber0;
            ThisTrainerid = S.TrainerID0;

        }

        private void blProfilePage_Click(object sender, EventArgs e)
        {

        }

        private void lblName_click(object sender, EventArgs e)
        {

        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblEmail_click(object sender, EventArgs e)
        {

        }

        private void lblPassword_click(object sender, EventArgs e)
        {

        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPhoneNum_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Trainer obj1 = new Trainer(Name);
            MessageBox.Show(obj1.UpdateProfile(txtName.Text, txtEmail.Text, txtPassword.Text, txtPhoneNum.Text, ThisTrainerid));
        }

        private void btnReturn_click(object sender, EventArgs e)
        {
            this.Hide();
            TrainerHomepage f1 = new TrainerHomepage();
            f1.Show();
        }
    }
}

﻿using G23Assignment.G23Assignment;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace G23Assignment
{
    public partial class Trainer_Feedback_page : Form
    {
        private string selectedTrainerName;
        public Trainer_Feedback_page(string N)
        {
            InitializeComponent();
            Name = N;
        }
        private void btnReturn_Click(object sender, EventArgs e)
        {
            //string Name = "luai";
            this.Close();

            Admin_Homepage ah = new Admin_Homepage(Name);
            ah.Show();
        }

        private void cboTrainerName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboTrainerName.SelectedItem != null)
            {
                selectedTrainerName = cboTrainerName.SelectedItem.ToString();
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(selectedTrainerName))
            {
                string feedback = Admin.GetTrainerFeedback(selectedTrainerName);
                txtFeedback.Text = feedback;
            }
            else
            {
                MessageBox.Show("Please select a trainer.");
            }
        }

        private void Trainer_Feedback_page_Load(object sender, EventArgs e)
        {
            List<string> trainerNames = Admin.ViewAll();

            cboTrainerName.Items.Clear();
            cboTrainerName.Items.AddRange(trainerNames.ToArray());
        }
    }
}

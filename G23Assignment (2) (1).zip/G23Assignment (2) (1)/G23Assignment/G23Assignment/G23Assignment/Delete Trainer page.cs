﻿using G23Assignment.G23Assignment;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace G23Assignment
{
    public partial class Delete_Trainer_page : Form
    {
        private Admin A;
        public Delete_Trainer_page(string adminName)
        {
            InitializeComponent();
            A = new Admin(adminName);
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            // Open the admin homepage form
            this.Close();
            Admin_Homepage ah = new Admin_Homepage(A.Name1);
            ah.Show();
        }

        private void Delete_Trainer_page_Load(object sender, EventArgs e)
        {
            LoadTrainerList(); // Load the trainer list
        }

        private void LoadTrainerList()
        {
            lstTrainerList.Items.Clear();

            // get the list of trainer names using method ViewAll() of the Admin class
            List<string> names = Admin.ViewAll();
            foreach (var name in names)
            {
                lstTrainerList.Items.Add(name.ToString());
            }
        }

        private void lstTrainerList_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstTrainerList.SelectedIndex != -1) // Check if a trainer is selected
            {
                string selectedTrainer = lstTrainerList.SelectedItem.ToString();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

            if (lstTrainerList.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a trainer to delete.");
            }
            else
            {
                string selectedTrainer = lstTrainerList.SelectedItem.ToString();

                // Delete the selected trainer from the Trainer and users tables in the database
                using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString()))
                {
                    con.Open();

                    // Delete trainer query
                    string deleteTrainerQuery = "DELETE FROM Trainer WHERE Name = @TrainerName";
                    SqlCommand deleteTrainerCmd = new SqlCommand(deleteTrainerQuery, con);
                    deleteTrainerCmd.Parameters.AddWithValue("@TrainerName", selectedTrainer);

                    int trainerRowsAffected = deleteTrainerCmd.ExecuteNonQuery();

                    // Delete user query
                    string deleteUserQuery = "DELETE FROM users WHERE Name = @TrainerName";
                    SqlCommand deleteUserCmd = new SqlCommand(deleteUserQuery, con);
                    deleteUserCmd.Parameters.AddWithValue("@TrainerName", selectedTrainer);

                    int userRowsAffected = deleteUserCmd.ExecuteNonQuery();

                    // Check if the deletion was successful
                    if (trainerRowsAffected > 0 && userRowsAffected > 0)
                    {
                        MessageBox.Show("Trainer deleted successfully.");
                        lstTrainerList.Items.Remove(selectedTrainer);
                    }
                    else
                    {
                        MessageBox.Show("Failed to delete the trainer.");
                    }
                }
            }
        }
    }
}

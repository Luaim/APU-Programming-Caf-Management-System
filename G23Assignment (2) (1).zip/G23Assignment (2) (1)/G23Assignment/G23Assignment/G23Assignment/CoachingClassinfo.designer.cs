﻿namespace G23Assignment
{
    partial class CoachingClassinfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCoachInfo = new System.Windows.Forms.Label();
            this.lblAddCoach = new System.Windows.Forms.Label();
            this.lblModuleName = new System.Windows.Forms.Label();
            this.lblModuleLevel = new System.Windows.Forms.Label();
            this.lblCharges = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblTime = new System.Windows.Forms.Label();
            this.txtModuleName = new System.Windows.Forms.TextBox();
            this.txtModuleLevel = new System.Windows.Forms.TextBox();
            this.txtCharges = new System.Windows.Forms.TextBox();
            this.txtDate = new System.Windows.Forms.TextBox();
            this.txtTime = new System.Windows.Forms.TextBox();
            this.btnsubmit = new System.Windows.Forms.Button();
            this.btnDisplay = new System.Windows.Forms.Button();
            this.btndelete = new System.Windows.Forms.Button();
            this.btnreturn = new System.Windows.Forms.Button();
            this.lblCoachList = new System.Windows.Forms.Label();
            this.LstCoachingList = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.LstCoachingList)).BeginInit();
            this.SuspendLayout();
            // 
            // lblCoachInfo
            // 
            this.lblCoachInfo.AutoSize = true;
            this.lblCoachInfo.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCoachInfo.Location = new System.Drawing.Point(269, 9);
            this.lblCoachInfo.Name = "lblCoachInfo";
            this.lblCoachInfo.Size = new System.Drawing.Size(229, 22);
            this.lblCoachInfo.TabIndex = 0;
            this.lblCoachInfo.Text = "Coaching Class Information";
            this.lblCoachInfo.Click += new System.EventHandler(this.lblCoachInfo_Click);
            // 
            // lblAddCoach
            // 
            this.lblAddCoach.AutoSize = true;
            this.lblAddCoach.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddCoach.Location = new System.Drawing.Point(42, 12);
            this.lblAddCoach.Name = "lblAddCoach";
            this.lblAddCoach.Size = new System.Drawing.Size(139, 19);
            this.lblAddCoach.TabIndex = 1;
            this.lblAddCoach.Text = "Add coaching class";
            this.lblAddCoach.Click += new System.EventHandler(this.lblAddCoach_Click);
            // 
            // lblModuleName
            // 
            this.lblModuleName.AutoSize = true;
            this.lblModuleName.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModuleName.Location = new System.Drawing.Point(43, 63);
            this.lblModuleName.Name = "lblModuleName";
            this.lblModuleName.Size = new System.Drawing.Size(106, 19);
            this.lblModuleName.TabIndex = 2;
            this.lblModuleName.Text = "Module Name";
            this.lblModuleName.Click += new System.EventHandler(this.lblModuleName_Click);
            // 
            // lblModuleLevel
            // 
            this.lblModuleLevel.AutoSize = true;
            this.lblModuleLevel.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModuleLevel.Location = new System.Drawing.Point(42, 93);
            this.lblModuleLevel.Name = "lblModuleLevel";
            this.lblModuleLevel.Size = new System.Drawing.Size(104, 19);
            this.lblModuleLevel.TabIndex = 3;
            this.lblModuleLevel.Text = "Module Level";
            this.lblModuleLevel.Click += new System.EventHandler(this.lblModuleLevel_click);
            // 
            // lblCharges
            // 
            this.lblCharges.AutoSize = true;
            this.lblCharges.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCharges.Location = new System.Drawing.Point(42, 124);
            this.lblCharges.Name = "lblCharges";
            this.lblCharges.Size = new System.Drawing.Size(64, 19);
            this.lblCharges.TabIndex = 4;
            this.lblCharges.Text = "Charges";
            this.lblCharges.Click += new System.EventHandler(this.lblCharges_click);
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.Location = new System.Drawing.Point(43, 158);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(41, 19);
            this.lblDate.TabIndex = 5;
            this.lblDate.Text = "Date";
            this.lblDate.Click += new System.EventHandler(this.lblDate_Click);
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTime.Location = new System.Drawing.Point(43, 189);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(43, 19);
            this.lblTime.TabIndex = 6;
            this.lblTime.Text = "Time";
            this.lblTime.Click += new System.EventHandler(this.Time_click);
            // 
            // txtModuleName
            // 
            this.txtModuleName.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtModuleName.Location = new System.Drawing.Point(190, 55);
            this.txtModuleName.Name = "txtModuleName";
            this.txtModuleName.Size = new System.Drawing.Size(334, 27);
            this.txtModuleName.TabIndex = 7;
            this.txtModuleName.TextChanged += new System.EventHandler(this.txtModuleName_TextChanged);
            // 
            // txtModuleLevel
            // 
            this.txtModuleLevel.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtModuleLevel.Location = new System.Drawing.Point(190, 85);
            this.txtModuleLevel.Name = "txtModuleLevel";
            this.txtModuleLevel.Size = new System.Drawing.Size(334, 27);
            this.txtModuleLevel.TabIndex = 8;
            this.txtModuleLevel.TextChanged += new System.EventHandler(this.txtModuleLevel_TextChanged);
            // 
            // txtCharges
            // 
            this.txtCharges.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCharges.Location = new System.Drawing.Point(190, 116);
            this.txtCharges.Name = "txtCharges";
            this.txtCharges.Size = new System.Drawing.Size(334, 27);
            this.txtCharges.TabIndex = 9;
            this.txtCharges.TextChanged += new System.EventHandler(this.txtCharges_TextChanged);
            // 
            // txtDate
            // 
            this.txtDate.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDate.Location = new System.Drawing.Point(190, 150);
            this.txtDate.Name = "txtDate";
            this.txtDate.Size = new System.Drawing.Size(334, 27);
            this.txtDate.TabIndex = 10;
            this.txtDate.TextChanged += new System.EventHandler(this.txtDate_TextChanged);
            // 
            // txtTime
            // 
            this.txtTime.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTime.Location = new System.Drawing.Point(190, 181);
            this.txtTime.Name = "txtTime";
            this.txtTime.Size = new System.Drawing.Size(334, 27);
            this.txtTime.TabIndex = 11;
            this.txtTime.TextChanged += new System.EventHandler(this.txtTime_TextChanged);
            // 
            // btnsubmit
            // 
            this.btnsubmit.BackColor = System.Drawing.Color.Azure;
            this.btnsubmit.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsubmit.Location = new System.Drawing.Point(284, 214);
            this.btnsubmit.Name = "btnsubmit";
            this.btnsubmit.Size = new System.Drawing.Size(120, 36);
            this.btnsubmit.TabIndex = 12;
            this.btnsubmit.Text = "Submit";
            this.btnsubmit.UseVisualStyleBackColor = false;
            this.btnsubmit.Click += new System.EventHandler(this.btnsubmit_click);
            // 
            // btnDisplay
            // 
            this.btnDisplay.BackColor = System.Drawing.Color.Azure;
            this.btnDisplay.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDisplay.Location = new System.Drawing.Point(652, 272);
            this.btnDisplay.Name = "btnDisplay";
            this.btnDisplay.Size = new System.Drawing.Size(120, 36);
            this.btnDisplay.TabIndex = 13;
            this.btnDisplay.Text = "Display";
            this.btnDisplay.UseVisualStyleBackColor = false;
            this.btnDisplay.Click += new System.EventHandler(this.btnDisplay_Click);
            // 
            // btndelete
            // 
            this.btndelete.BackColor = System.Drawing.Color.Azure;
            this.btndelete.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndelete.Location = new System.Drawing.Point(652, 328);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(120, 36);
            this.btndelete.TabIndex = 14;
            this.btndelete.Text = "Delete";
            this.btndelete.UseVisualStyleBackColor = false;
            this.btndelete.Click += new System.EventHandler(this.btndelete_click);
            // 
            // btnreturn
            // 
            this.btnreturn.BackColor = System.Drawing.Color.Azure;
            this.btnreturn.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnreturn.Location = new System.Drawing.Point(652, 386);
            this.btnreturn.Name = "btnreturn";
            this.btnreturn.Size = new System.Drawing.Size(120, 36);
            this.btnreturn.TabIndex = 15;
            this.btnreturn.Text = "Return";
            this.btnreturn.UseVisualStyleBackColor = false;
            this.btnreturn.Click += new System.EventHandler(this.btnreturn_Click);
            // 
            // lblCoachList
            // 
            this.lblCoachList.AutoSize = true;
            this.lblCoachList.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCoachList.Location = new System.Drawing.Point(42, 235);
            this.lblCoachList.Name = "lblCoachList";
            this.lblCoachList.Size = new System.Drawing.Size(145, 19);
            this.lblCoachList.TabIndex = 16;
            this.lblCoachList.Text = "Coaching Class List";
            this.lblCoachList.Click += new System.EventHandler(this.lblCoachList_click);
            // 
            // LstCoachingList
            // 
            this.LstCoachingList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.LstCoachingList.Location = new System.Drawing.Point(12, 272);
            this.LstCoachingList.Name = "LstCoachingList";
            this.LstCoachingList.RowHeadersWidth = 51;
            this.LstCoachingList.RowTemplate.Height = 24;
            this.LstCoachingList.Size = new System.Drawing.Size(612, 150);
            this.LstCoachingList.TabIndex = 17;
            this.LstCoachingList.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.LstCoachingList_CellContentClick);
            // 
            // CoachingClassinfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LstCoachingList);
            this.Controls.Add(this.lblCoachList);
            this.Controls.Add(this.btnreturn);
            this.Controls.Add(this.btndelete);
            this.Controls.Add(this.btnDisplay);
            this.Controls.Add(this.btnsubmit);
            this.Controls.Add(this.txtTime);
            this.Controls.Add(this.txtDate);
            this.Controls.Add(this.txtCharges);
            this.Controls.Add(this.txtModuleLevel);
            this.Controls.Add(this.txtModuleName);
            this.Controls.Add(this.lblTime);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.lblCharges);
            this.Controls.Add(this.lblModuleLevel);
            this.Controls.Add(this.lblModuleName);
            this.Controls.Add(this.lblAddCoach);
            this.Controls.Add(this.lblCoachInfo);
            this.Name = "CoachingClassinfo";
            this.Text = "CoachingClassinfo";
            ((System.ComponentModel.ISupportInitialize)(this.LstCoachingList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCoachInfo;
        private System.Windows.Forms.Label lblAddCoach;
        private System.Windows.Forms.Label lblModuleName;
        private System.Windows.Forms.Label lblModuleLevel;
        private System.Windows.Forms.Label lblCharges;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.TextBox txtModuleName;
        private System.Windows.Forms.TextBox txtModuleLevel;
        private System.Windows.Forms.TextBox txtCharges;
        private System.Windows.Forms.TextBox txtDate;
        private System.Windows.Forms.TextBox txtTime;
        private System.Windows.Forms.Button btnsubmit;
        private System.Windows.Forms.Button btnDisplay;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.Button btnreturn;
        private System.Windows.Forms.Label lblCoachList;
        private System.Windows.Forms.DataGridView LstCoachingList;
    }
}
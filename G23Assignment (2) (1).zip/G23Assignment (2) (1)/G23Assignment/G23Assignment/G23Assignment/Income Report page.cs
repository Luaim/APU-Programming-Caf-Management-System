﻿using G23Assignment.G23Assignment;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace G23Assignment
{
    public partial class Income_Report_page : Form
    {
        
        public Income_Report_page(string N)
        {
            InitializeComponent();
            Name = N;
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            //Name = "luai";
            this.Close();
            // Open the admin homepage form
            Admin_Homepage ah = new Admin_Homepage(Name);
            ah.Show();
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            string name = cboTrainerName.Text;
            string level = cboLevel.Text;
            string module = cboModule.Text;
            string incomeReport = "";

            Admin admin = new Admin(name, "", "", "", "", "", level, module);
            // Call the MonthlyIncome method of the Admin class to calculate the monthly income and get the income report
            decimal monthlyIncome = Admin.MonthlyIncome(admin, out incomeReport);
            // Display the income report in the text box
            txtMonthlyIncome.Text = incomeReport;
        }

        private void Income_Report_page_Load(object sender, EventArgs e)
        {
            // get the list of trainers, levels, and modules using  methods of the Admin class
            List<string> trainers = Admin.ViewAll();
            List<string> levels = Admin.GetLevel();
            List<string> modules = Admin.GetModule();

            cboTrainerName.Items.Clear();
            cboTrainerName.Items.AddRange(trainers.ToArray());

            cboLevel.Items.Clear();
            cboLevel.Items.AddRange(levels.ToArray());

            cboModule.Items.Clear();
            cboModule.Items.AddRange(modules.ToArray());
        }
    }
}

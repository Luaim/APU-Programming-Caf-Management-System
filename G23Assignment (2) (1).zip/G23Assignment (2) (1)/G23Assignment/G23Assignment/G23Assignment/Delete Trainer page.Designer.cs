﻿namespace G23Assignment
{
    partial class Delete_Trainer_page
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblDeleteTrainer = new System.Windows.Forms.Label();
            this.lblTrainerList = new System.Windows.Forms.Label();
            this.lstTrainerList = new System.Windows.Forms.ListBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnReturn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblDeleteTrainer
            // 
            this.lblDeleteTrainer.AutoSize = true;
            this.lblDeleteTrainer.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDeleteTrainer.Location = new System.Drawing.Point(325, 37);
            this.lblDeleteTrainer.Name = "lblDeleteTrainer";
            this.lblDeleteTrainer.Size = new System.Drawing.Size(143, 26);
            this.lblDeleteTrainer.TabIndex = 1;
            this.lblDeleteTrainer.Text = "Delete Trainer";
            // 
            // lblTrainerList
            // 
            this.lblTrainerList.AutoSize = true;
            this.lblTrainerList.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTrainerList.Location = new System.Drawing.Point(157, 122);
            this.lblTrainerList.Name = "lblTrainerList";
            this.lblTrainerList.Size = new System.Drawing.Size(103, 22);
            this.lblTrainerList.TabIndex = 2;
            this.lblTrainerList.Text = "Trainer List";
            // 
            // lstTrainerList
            // 
            this.lstTrainerList.BackColor = System.Drawing.Color.Azure;
            this.lstTrainerList.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstTrainerList.ForeColor = System.Drawing.Color.Black;
            this.lstTrainerList.FormattingEnabled = true;
            this.lstTrainerList.ItemHeight = 19;
            this.lstTrainerList.Items.AddRange(new object[] {
            "",
            "",
            "",
            "",
            "",
            ""});
            this.lstTrainerList.Location = new System.Drawing.Point(287, 122);
            this.lstTrainerList.Name = "lstTrainerList";
            this.lstTrainerList.Size = new System.Drawing.Size(194, 156);
            this.lstTrainerList.TabIndex = 3;
            this.lstTrainerList.SelectedIndexChanged += new System.EventHandler(this.lstTrainerList_SelectedIndexChanged);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.Azure;
            this.btnDelete.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnDelete.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.ForeColor = System.Drawing.Color.Black;
            this.btnDelete.Location = new System.Drawing.Point(253, 356);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(120, 36);
            this.btnDelete.TabIndex = 6;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnReturn
            // 
            this.btnReturn.BackColor = System.Drawing.Color.Azure;
            this.btnReturn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnReturn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReturn.ForeColor = System.Drawing.Color.Black;
            this.btnReturn.Location = new System.Drawing.Point(404, 356);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(120, 36);
            this.btnReturn.TabIndex = 7;
            this.btnReturn.Text = "Return";
            this.btnReturn.UseVisualStyleBackColor = false;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // Delete_Trainer_page
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(832, 457);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.lstTrainerList);
            this.Controls.Add(this.lblTrainerList);
            this.Controls.Add(this.lblDeleteTrainer);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Delete_Trainer_page";
            this.Text = "Delete_Trainer_page";
            this.Load += new System.EventHandler(this.Delete_Trainer_page_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblDeleteTrainer;
        private System.Windows.Forms.Label lblTrainerList;
        private System.Windows.Forms.ListBox lstTrainerList;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnReturn;
    }
}
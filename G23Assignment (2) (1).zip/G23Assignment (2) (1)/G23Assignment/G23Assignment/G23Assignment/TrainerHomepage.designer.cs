﻿namespace G23Assignment
{
    partial class TrainerHomepage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTraineeHomepage = new System.Windows.Forms.Label();
            this.Welcome = new System.Windows.Forms.Label();
            this.btnProfile = new System.Windows.Forms.Button();
            this.btnCoachingClasses = new System.Windows.Forms.Button();
            this.btnAdminFeedback = new System.Windows.Forms.Button();
            this.btnStudentList = new System.Windows.Forms.Button();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTraineeHomepage
            // 
            this.lblTraineeHomepage.AutoSize = true;
            this.lblTraineeHomepage.BackColor = System.Drawing.Color.Transparent;
            this.lblTraineeHomepage.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTraineeHomepage.Location = new System.Drawing.Point(309, 39);
            this.lblTraineeHomepage.Name = "lblTraineeHomepage";
            this.lblTraineeHomepage.Size = new System.Drawing.Size(159, 22);
            this.lblTraineeHomepage.TabIndex = 0;
            this.lblTraineeHomepage.Text = "Trainee Homepage";
            this.lblTraineeHomepage.Click += new System.EventHandler(this.lblTraineeHomepage_Click);
            // 
            // Welcome
            // 
            this.Welcome.AutoSize = true;
            this.Welcome.BackColor = System.Drawing.Color.Transparent;
            this.Welcome.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Welcome.Location = new System.Drawing.Point(322, 76);
            this.Welcome.Name = "Welcome";
            this.Welcome.Size = new System.Drawing.Size(75, 19);
            this.Welcome.TabIndex = 1;
            this.Welcome.Text = "Welcome";
            this.Welcome.Click += new System.EventHandler(this.lblWelcome_Click);
            // 
            // btnProfile
            // 
            this.btnProfile.BackColor = System.Drawing.Color.AliceBlue;
            this.btnProfile.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProfile.Location = new System.Drawing.Point(201, 147);
            this.btnProfile.Name = "btnProfile";
            this.btnProfile.Size = new System.Drawing.Size(120, 36);
            this.btnProfile.TabIndex = 2;
            this.btnProfile.Text = "Profile";
            this.btnProfile.UseVisualStyleBackColor = false;
            this.btnProfile.Click += new System.EventHandler(this.btnProfile_Click);
            // 
            // btnCoachingClasses
            // 
            this.btnCoachingClasses.BackColor = System.Drawing.Color.AliceBlue;
            this.btnCoachingClasses.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCoachingClasses.Location = new System.Drawing.Point(472, 147);
            this.btnCoachingClasses.Name = "btnCoachingClasses";
            this.btnCoachingClasses.Size = new System.Drawing.Size(120, 36);
            this.btnCoachingClasses.TabIndex = 3;
            this.btnCoachingClasses.Text = "Coaching Classes";
            this.btnCoachingClasses.UseVisualStyleBackColor = false;
            this.btnCoachingClasses.Click += new System.EventHandler(this.btnCoachingClasses_Click);
            // 
            // btnAdminFeedback
            // 
            this.btnAdminFeedback.BackColor = System.Drawing.Color.AliceBlue;
            this.btnAdminFeedback.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdminFeedback.Location = new System.Drawing.Point(201, 228);
            this.btnAdminFeedback.Name = "btnAdminFeedback";
            this.btnAdminFeedback.Size = new System.Drawing.Size(120, 36);
            this.btnAdminFeedback.TabIndex = 4;
            this.btnAdminFeedback.Text = "Admin Feedback";
            this.btnAdminFeedback.UseVisualStyleBackColor = false;
            this.btnAdminFeedback.Click += new System.EventHandler(this.btnAdminFeedback_Click);
            // 
            // btnStudentList
            // 
            this.btnStudentList.BackColor = System.Drawing.Color.AliceBlue;
            this.btnStudentList.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStudentList.Location = new System.Drawing.Point(472, 228);
            this.btnStudentList.Name = "btnStudentList";
            this.btnStudentList.Size = new System.Drawing.Size(120, 36);
            this.btnStudentList.TabIndex = 5;
            this.btnStudentList.Text = "Student List";
            this.btnStudentList.UseVisualStyleBackColor = false;
            this.btnStudentList.Click += new System.EventHandler(this.btnStudentList_Click);
            // 
            // btnLogOut
            // 
            this.btnLogOut.BackColor = System.Drawing.Color.AliceBlue;
            this.btnLogOut.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogOut.Location = new System.Drawing.Point(348, 321);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(120, 36);
            this.btnLogOut.TabIndex = 6;
            this.btnLogOut.Text = "Log Out";
            this.btnLogOut.UseVisualStyleBackColor = false;
            this.btnLogOut.Click += new System.EventHandler(this.btnLogOut_Click);
            // 
            // TrainerHomepage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::G23Assignment.Properties.Resources.c_71;
            this.ClientSize = new System.Drawing.Size(833, 494);
            this.Controls.Add(this.btnLogOut);
            this.Controls.Add(this.btnStudentList);
            this.Controls.Add(this.btnAdminFeedback);
            this.Controls.Add(this.btnCoachingClasses);
            this.Controls.Add(this.btnProfile);
            this.Controls.Add(this.Welcome);
            this.Controls.Add(this.lblTraineeHomepage);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "TrainerHomepage";
            this.Text = "TrainerHomepage";
            this.Load += new System.EventHandler(this.TrainerHomepage_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTraineeHomepage;
        private System.Windows.Forms.Label Welcome;
        private System.Windows.Forms.Button btnProfile;
        private System.Windows.Forms.Button btnCoachingClasses;
        private System.Windows.Forms.Button btnAdminFeedback;
        private System.Windows.Forms.Button btnStudentList;
        private System.Windows.Forms.Button btnLogOut;
    }
}
﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace G23Assignment
{
    public partial class Deletestudents : Form
    {
        public Deletestudents()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Deletestudents_Load(object sender, EventArgs e)
        {
            ArrayList ds = new ArrayList();

            ds = students.DelStud();
            foreach (var item in ds)
            {
                lstName1.Items.Add(item);


            }
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            students obj1 = new students(lstName1.SelectedItems.ToString());
            MessageBox.Show(obj1.DelBtn(lstName1));

            while (lstName1.SelectedItems.Count > 0)
            {
                lstName1.Items.Remove(lstName1.SelectedItems[0]);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace G23Assignment
{
    public partial class TrainerHomepage : Form
    {
        public static string name;
        public TrainerHomepage()
        {
            InitializeComponent();
            
        }

        private void TrainerHomepage_Load(object sender, EventArgs e)
        {

        }

        private void lblTraineeHomepage_Click(object sender, EventArgs e)
        {

        }

        private void lblWelcome_Click(object sender, EventArgs e)
        {

        }

        private void btnProfile_Click(object sender, EventArgs e)
        {
            this.Hide();
            TrainerProfile f2 = new TrainerProfile();
            f2.Show();
        }

        private void btnCoachingClasses_Click(object sender, EventArgs e)
        {
            this.Hide();
            CoachingClassinfo f3 = new CoachingClassinfo();
            f3.Show();
        }

        private void btnStudentList_Click(object sender, EventArgs e)
        {
            this.Hide();
            StudentList f5 = new StudentList();
            f5.Show();
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {

        }

        private void btnAdminFeedback_Click(object sender, EventArgs e)
        {
            this.Hide();
            Feedback f4 = new Feedback();
            f4.Show();
        }
    }
}

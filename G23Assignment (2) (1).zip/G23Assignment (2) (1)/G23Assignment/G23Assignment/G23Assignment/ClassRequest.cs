﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace G23Assignment
{
    public partial class frmClassRequest : Form
    {
         
        public static string Name;
        public frmClassRequest()
        {
            InitializeComponent();
        }
        public frmClassRequest(string n)
        {
            InitializeComponent();
            Name = n;
        }


        

        private void frmClassRequest_Load(object sender, EventArgs e)
        {

        }

        private void btnRequest_Click(object sender, EventArgs e)
        {
            Student S = new Student(Name, cboModule.GetItemText(cboModule.SelectedItem), cboLevel.GetItemText(cboLevel.SelectedItem));
            
            MessageBox.Show("Request submission is Succesful.");

            lblRequestBio.Text = "Module: " + cboModule.GetItemText(cboModule.SelectedItem) + "     " + "Level: " + cboLevel.GetItemText(cboLevel.SelectedItem) + "     " + "  RequestStatus: Pending"; ;


        }


        private void btnDelete_Click(object sender, EventArgs e)

        {
            Student obj3 = new Student(Name, cboModule.GetItemText(cboModule.SelectedItem), cboLevel.GetItemText(cboLevel.SelectedItem));
            MessageBox.Show(obj3.RequestStatusUpdate());

            lblRequestBio.Text = "Module: " + cboModule.GetItemText(cboModule.SelectedItem) + "     " + "Level: " + cboLevel.GetItemText(cboLevel.SelectedItem) + "     " + "  RequestStatus: Deleted"; ;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Close();
            frmStudentHomePage S = new frmStudentHomePage(Name);
            S.ShowDialog();
        }
    }
}

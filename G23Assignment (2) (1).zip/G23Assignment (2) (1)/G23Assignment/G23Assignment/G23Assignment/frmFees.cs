﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace G23Assignment
{
    public partial class frmFees : Form
    {
        public static string Name;
        public frmFees()
        {
            InitializeComponent();
            
        }

        public frmFees(string n) 
        {
            InitializeComponent();
            Name = n;
        }

        private void frmFees_Load(object sender, EventArgs e)
        {
            Student P = new Student(Name);

            Student.Fees(P);

            
            
                
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Close();
            frmStudentHomePage f1 = new frmStudentHomePage(Name);
            f1.Show();
        }

        private void btnPay_Click(object sender, EventArgs e)
        {
            Student o1 = new Student(Name);
            MessageBox.Show(o1.FeesUpdate());
        }
    }
}

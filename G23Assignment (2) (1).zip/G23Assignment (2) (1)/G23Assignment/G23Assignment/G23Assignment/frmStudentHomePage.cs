﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace G23Assignment
{
    
    public partial class frmStudentHomePage : Form
    {
        public static string Name;

        public frmStudentHomePage(string n)
        {
            InitializeComponent();
            Name = n;
        }
        

        private void btnProfile_Click(object sender, EventArgs e)
        {
            this.Close();
            frmProfile f1 = new frmProfile(Name);
            f1.ShowDialog();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
            frmLogin f1 = new frmLogin();
            f1.ShowDialog();
        }

        private void frmStudentHomePage_Load(object sender, EventArgs e)
        {

        }

        private void btnFees_Click(object sender, EventArgs e)
        {
            frmFees f1 = new frmFees();
            f1.ShowDialog();
        }

        private void btnClassRequest_Click(object sender, EventArgs e)
        {
            frmClassRequest f1 = new frmClassRequest();
            f1.ShowDialog();
        }

        private void btnClassSchedule_Click(object sender, EventArgs e)
        {
            frmClassSchedule f1 = new frmClassSchedule();
            f1.ShowDialog();
        }
    }
}
